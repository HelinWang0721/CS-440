import math
numARows = 458
numAColumns= 4
numBRows = 4 
numBColumns = 81
numCRows = 458
numCColumns= 81
tilesize = 16

Xtiles = math.ceil(numCColumns/tilesize)
